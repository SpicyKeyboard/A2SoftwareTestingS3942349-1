package org.example;

public class PasswordValidationException extends Exception{

    public PasswordValidationException (String message, Throwable cause)
    {
        super (message, cause);
    }
}
