package org.example;

import com.inflectra.spiratest.addons.junitextension.SpiraTestCase;
import com.inflectra.spiratest.addons.junitextension.SpiraTestConfiguration;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@SpiraTestConfiguration(
        //following are REQUIRED
        url = "https://rmit.spiraservice.net",
        login = "S3942349",
        rssToken = "{9173EE78-FAC9-477B-B21F-47F01A086698}",
        projectId = 105,
        //following are OPTIONAL
        releaseId = 280,
        testSetId = 191
)


class EventTest { //all tests assume that the original provided txt files are used

    Event ems = new Event();
    static ArrayList<BasicData> Student;




    @BeforeAll
    static void readStudentList() throws IOException { //an exert from the Event class to read the txt file into an arrayList
        Student = new ArrayList<BasicData>();
        BufferedReader in_Student = new BufferedReader (new FileReader("student.txt"));

        String s;
        String id;
        String name;
        String password;

        while((s = in_Student.readLine()) != null)
        {
            id = s.substring(3,s.indexOf("Name") - 2);
            name = s.substring(s.indexOf("Name") + 5, s.indexOf("Password") - 2);
            password = s.substring(s.indexOf("Password") + 9, s.length());

            BasicData obj = new BasicData(Integer.parseInt(id), name, password);
            Student.add(obj);
        }

        in_Student.close();
    }

    @AfterEach
    void setStudentList() throws IOException { //an exert from the Event class' rewrite student file that will rewrite the file after each test back to the original txt.
        BufferedWriter out_Student = new BufferedWriter (new FileWriter("student.txt"));

        for(int i = 0; i < Student.size();i++)
        {
            out_Student.write("Id:" + Student.get(i).getID() + ", ");
            out_Student.write("Name:" + Student.get(i).getName() + ", ");
            out_Student.write("Password:" + Student.get(i).getPassword());
            out_Student.write("\n");
        }

        out_Student.close();
    }

    @Test
    @SpiraTestCase(testCaseId = 1726)
    public void adminLoginPassTest() {
        System.setIn(new ByteArrayInputStream("Admin1\npass1\n1\n".getBytes()));
        assertTrue(ems.AdminLogin());
    }

    @Test
    @SpiraTestCase(testCaseId = 1727)
    public void adminLoginFailTest() {
        System.setIn(new ByteArrayInputStream("not-admin\npass1\n1\n".getBytes()));
        assertFalse(ems.AdminLogin());
    }

    @Test
    @SpiraTestCase(testCaseId = 1728)
    public void studentLoginPassTest() {
        System.setIn(new ByteArrayInputStream("7654324\np7654324#\n".getBytes()));
        assertTrue(ems.StudentLogin());
    }

    @Test
    @SpiraTestCase(testCaseId = 1729)
    public void studentLoginFailTest() {
        System.setIn(new ByteArrayInputStream("7654324\nnot-a-password\n".getBytes()));
        assertFalse(ems.StudentLogin());
    }

    @Test //done
    @SpiraTestCase(testCaseId = 1705)
    public void showStudentEventsTest() { //must be the same as the provided txt file
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        PrintStream prints = new PrintStream(bytes);
        PrintStream old = System.out;
        System.setOut(prints);
        ems.showStudentEvents();
        System.out.flush();
        System.setOut(old);
        assertEquals(bytes.toString(), "\nList of Events: \r\n" +
                "o Wild Hope: Conversations for a Planetary Commons 15 Aug 2023 - 30 Sep 2023\r\n" +
                "o Urban Futures Symposium 21 Aug 2023 - 25 Aug 2023\r\n" +
                "o ‘Basalt Study’ by Christine McFetridge 22 Aug 2023 - 15 Sep 2023\r\n" +
                "o ‘The Dark Botanical Garden’ by Pug 22 Aug 2023 - 15 Sep 2023\r\n" +
                "o ‘Off the Well-Worn Path’ by Ryley Clarke 22 Aug 2023 - 15 Sep 2023\r\n" +
                "o Future Play Lab: TRON (1982) 19 Sep 2023\r\n");
    }

    @Test //done
    @SpiraTestCase(testCaseId = 1706)
    public void viewStudentDetailsTest() { //student txt file must be unedited
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        PrintStream prints = new PrintStream(bytes);
        PrintStream old = System.out;
        System.setOut(prints);
        ems.viewStudentDetails();
        System.out.flush();
        System.setOut(old);
        assertEquals(bytes.toString(), "\nDetails of All Student:.\n" +
                "ID: 7654324\r\n" +
                "Name: Student1\r\n" +
                "Password: p7654324#\r\n" +
                "\n" +
                "ID: 7654325\r\n" +
                "Name: Student2\r\n" +
                "Password: p7654325#\r\n" +
                "\n" +
                "ID: 7654326\r\n" +
                "Name: Student3\r\n" +
                "Password: p7654326#\r\n" +
                "\n" +
                "ID: 7654327\r\n" +
                "Name: Student4\r\n" +
                "Password: p7654327#\r\n" +
                "\n" +
                "ID: 7654328\r\n" +
                "Name: Student5\r\n" +
                "Password: p7654328#\r\n" +
                "\n" +
                "ID: 7654329\r\n" +
                "Name: Student6\r\n" +
                "Password: p7654329#\r\n" +
                "\n" +
                "ID: 7654330\r\n" +
                "Name: Student7\r\n" +
                "Password: p7654330#\r\n" +
                "\n" +
                "ID: 7654331\r\n" +
                "Name: Student8\r\n" +
                "Password: p7654331#\r\n" +
                "\n" +
                "ID: 7654332\r\n" +
                "Name: Student9\r\n" +
                "Password: p7654332#\r\n");
    }

    @Test //done
    @SpiraTestCase(testCaseId = 1709)
    public void searchStudentDetailsTest() {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        PrintStream prints = new PrintStream(bytes);
        PrintStream old = System.out;
        System.setOut(prints);
        ems.searchStudentDetails(7654324);
        System.out.flush();
        System.setOut(old);
        assertAll(
                () -> assertTrue(ems.searchStudentDetails(7654324)), //this is the id of the first student in the provided txt
                () -> assertLinesMatch(bytes.toString().lines(), ("\n" + //makes sure that the output is correct for selected student
                                        "ID: 7654324\r\n" +
                                        "Name: Student1\r\n" +
                                        "Password: p7654324#\r\n").lines()),
                () -> assertFalse(ems.searchStudentDetails(0))
        );

    }

    @Test //done
    @SpiraTestCase(testCaseId = 1714)
    public void searchStudentDetailsFailureTest() { //should result in failure
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        PrintStream prints = new PrintStream(bytes);
        PrintStream old = System.out;
        System.setOut(prints);
        ems.searchStudentDetails(7654331);
        System.out.flush();
        System.setOut(old);
        assertAll(
                () -> assertTrue(ems.searchStudentDetails(7654331)), //this is the id of the first student in the provided txt
                () -> assertLinesMatch(bytes.toString().lines(), ("\n" + //makes sure that the output is correct for selected student
                        "ID: 7654324\r\n" +
                        "Name: Student1\r\n" +
                        "Password: p7654324#\r\n").lines()),
                () -> assertFalse(ems.searchStudentDetails(0))
        );

    }

    @Test //done
    @SpiraTestCase(testCaseId = 1698)
    public void countStudentTest() {
        assertAll(
                () -> assertEquals(9, ems.countStudent()), //must be the original txt file, or a different one that has 9 students
                () -> assertNotEquals(8, ems.countStudent())
        );

    }

    @Test //done
    @SpiraTestCase(testCaseId = 1712)
    public void removeStudentTest() {
        assertAll(
                () -> assertTrue(ems.removeStudent(7654324)), //this is the id of the first student in the provided txt
                () -> assertFalse(ems.removeStudent(0))
        );
    }

    @Test //done
    @SpiraTestCase(testCaseId = 1713)
    public void removeStudentFileRewriteTest() {
        ems.removeStudent(7654324); //remove student from list, this will also run the rewriteStudentFile method
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        PrintStream prints = new PrintStream(bytes);
        PrintStream old = System.out;
        System.setOut(prints);
        ems.viewStudentDetails();
        System.out.flush();
        System.setOut(old);
        assertEquals(bytes.toString(), "\nDetails of All Student:.\n" + //check the student txt file has the correct student removed.
                "ID: 7654325\r\n" +
                "Name: Student2\r\n" +
                "Password: p7654325#\r\n" +
                "\n" +
                "ID: 7654326\r\n" +
                "Name: Student3\r\n" +
                "Password: p7654326#\r\n" +
                "\n" +
                "ID: 7654327\r\n" +
                "Name: Student4\r\n" +
                "Password: p7654327#\r\n" +
                "\n" +
                "ID: 7654328\r\n" +
                "Name: Student5\r\n" +
                "Password: p7654328#\r\n" +
                "\n" +
                "ID: 7654329\r\n" +
                "Name: Student6\r\n" +
                "Password: p7654329#\r\n" +
                "\n" +
                "ID: 7654330\r\n" +
                "Name: Student7\r\n" +
                "Password: p7654330#\r\n" +
                "\n" +
                "ID: 7654331\r\n" +
                "Name: Student8\r\n" +
                "Password: p7654331#\r\n" +
                "\n" +
                "ID: 7654332\r\n" +
                "Name: Student9\r\n" +
                "Password: p7654332#\r\n");
    }

    @Test
    @SpiraTestCase(testCaseId = 1730)
    public void addStudentTest() {
        System.setIn(new ByteArrayInputStream("1234567\nStudentName\np1234567#\n".getBytes()));
        String methodReturn = ems.AddStudent();
        assertEquals(methodReturn, "Student Added Successfully");
    }

    @Test
    @SpiraTestCase(testCaseId = 1731)
    public void addStudentAlreadyExistsTest() {
        System.setIn(new ByteArrayInputStream("7654324\nStudent1\np7654324#\n".getBytes()));
        String methodReturn = ems.AddStudent();
        assertEquals(methodReturn, "Student Exists");
    }

    @Test
    @SpiraTestCase(testCaseId = 1732)
    public void addStudentPasswordValidationTestLength() {
        System.setIn(new ByteArrayInputStream("1234567\nStudentName\nnot-nine\n".getBytes()));
        String methodReturn = ems.AddStudent();
        assertEquals("Password length should be 9", methodReturn);
    }

    @Test
    @SpiraTestCase(testCaseId = 1733)
    public void addStudentPasswordValidationTestFirstChacter() {
        System.setIn(new ByteArrayInputStream("1234567\nStudentName\nl1234567#\n".getBytes()));
        String methodReturn = ems.AddStudent();
        assertEquals("First letter of the Password should be p", methodReturn);
    }

    @Test
    @SpiraTestCase(testCaseId = 1734)
    public void addStudentPasswordValidationTestLastChacter() {
        System.setIn(new ByteArrayInputStream("1234567\nStudentName\np1234567!\n".getBytes()));
        String methodReturn = ems.AddStudent();
        assertEquals("Last letter of the password should be #", methodReturn);
    }
}